package com.jingjiang.baidumusic.widget.myinterface;

import android.view.View;

/**
 * Created by dllo on 16/6/28.
 */
public interface OnViewPagerClickListener {
    void onClick(View view, int postion);
}
