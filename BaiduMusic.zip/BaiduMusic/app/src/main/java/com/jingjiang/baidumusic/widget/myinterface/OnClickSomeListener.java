package com.jingjiang.baidumusic.widget.myinterface;

/**
 * Created by dllo on 16/7/2.
 */
public interface OnClickSomeListener {
    void onClickSome();
}
