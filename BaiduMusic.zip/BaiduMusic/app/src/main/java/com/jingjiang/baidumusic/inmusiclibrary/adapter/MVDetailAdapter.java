package com.jingjiang.baidumusic.inmusiclibrary.adapter;

/**
 * Created by dllo on 16/7/4.
 */
public class MVDetailAdapter  {
}
