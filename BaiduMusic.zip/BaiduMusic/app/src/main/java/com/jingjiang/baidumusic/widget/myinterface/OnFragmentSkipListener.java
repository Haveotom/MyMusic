package com.jingjiang.baidumusic.widget.myinterface;


/**
 * Created by dllo on 16/6/29.
 */
public interface OnFragmentSkipListener {
    void toSkipFragment(int witch);//跳转fragment


}
