package com.jingjiang.baidumusic.inmymusic;

import com.litesuits.orm.db.annotation.PrimaryKey;
import com.litesuits.orm.db.enums.AssignType;

import java.io.Serializable;

/**
 * Created by dllo on 16/7/8.
 * 在 AndroidStudio 依次点击  tools Android  enable adb
 */
public class SingleSongData {
    @PrimaryKey(AssignType.AUTO_INCREMENT)
    private String title, author, songId;
    private int id;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getSongId() {
        return songId;
    }

    public void setSongId(String songId) {
        this.songId = songId;
    }
}
