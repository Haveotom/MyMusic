package com.jingjiang.baidumusic.individual.activity;

import android.app.Activity;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseActivity;

/**
 * Created by dllo on 16/6/29.
 */
public class ActiveActivity extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_individual_active;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
