package com.jingjiang.baidumusic.inmusicrecommend.data;

import java.util.List;

/**
 * Created by dllo on 16/7/5.
 * http://tingapi.ting.baidu.com/v1/restserver/ting?from=android&version=5.8.0.1&channel=xiaomi&operator=2&method=baidu.ting.tag.getAllTag&format=json&from=android&version=5.8.0.1
 */
public class ClassifyData {



}
