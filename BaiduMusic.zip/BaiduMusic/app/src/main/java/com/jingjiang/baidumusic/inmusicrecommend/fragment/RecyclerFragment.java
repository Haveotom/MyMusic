package com.jingjiang.baidumusic.inmusicrecommend.fragment;

import com.jingjiang.baidumusic.base.BaseFragment;

/**
 * Created by dllo on 16/7/5.
 */
public class RecyclerFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return 0;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
