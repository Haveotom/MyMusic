package com.jingjiang.baidumusic.activity;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.adapter.MainAdapter;
import com.jingjiang.baidumusic.base.BaseActivity;
import com.jingjiang.baidumusic.fragment.KSongFragment;
import com.jingjiang.baidumusic.fragment.LiveFragment;
import com.jingjiang.baidumusic.fragment.MyMusicFragment;
import com.jingjiang.baidumusic.fragment.MusicLibraryFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity implements View.OnClickListener {
    private MainAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private List<Fragment> fragments;
    private KSongFragment kSongFragment = new KSongFragment();
    private ImageView individualIv, searchIv;
    private DrawerLayout searchDrawer;//抽屉

    @Override
    protected int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        //初始化
        tabLayout = bindView(R.id.activity_main_tablayout);
        viewPager = bindView(R.id.activity_main_viewpager);
        individualIv = bindView(R.id.activity_main_singer);
        individualIv.setOnClickListener(this);
        adapter = new MainAdapter(getSupportFragmentManager());
        initFragments();
        adapter.setFragments(fragments);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        searchIv = bindView(R.id.activity_main_search);
        searchIv.setOnClickListener(this);
        searchDrawer = bindView(R.id.activity_main_drawer);
        //关闭滑动模式
//        searchDrawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

    }

    private void initFragments() {
        fragments = new ArrayList<>();
        fragments.add(new MyMusicFragment());
        fragments.add(new MusicLibraryFragment());
        fragments.add(kSongFragment);
        fragments.add(new LiveFragment());
    }

    @Override
    protected void initData() {
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 2) {
                    kSongFragment.setScroll();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_main_singer:
                startActivity(new Intent(this, IndividualActivity.class));
                overridePendingTransition(R.anim.activity_in, R.anim.activity_out);
                break;
            case R.id.activity_main_search:
                searchDrawer.openDrawer(GravityCompat.END);//打开抽屉

                break;
        }
        //http://api.69xiu.com/room/enterRoom?rid=75358333&mac=99000628573771&token=2z9KofX5l7024xAWAq6Ver69wIFlfcms29B1EDHBO48hAcoWpDgEmosIquEzTZsH%3Djia%3DDcC758Tav7IkNeukS4Ia4tDNQ7oazAh HTTP/1.1 	=> HTTP/1.1 200 OK	 [0.408 s]
        //http://api.69xiu.com/room/enterRoom?rid=%id&mac=99000628573771&token=2z9KofX5l7024xAWAq6Ver69wIFlfcms29B1EDHBO48hAcoWpDgEmosIquEzTZsH%3Djia%3DDcC758Tav7IkNeukS4Ia1PWYIofOkDi
    }
}
