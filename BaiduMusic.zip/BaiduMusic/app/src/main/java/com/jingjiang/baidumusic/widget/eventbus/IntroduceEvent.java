package com.jingjiang.baidumusic.widget.eventbus;

/**
 * Created by dllo on 16/7/7.
 */
public class IntroduceEvent {
    private int anInt;

    public IntroduceEvent(int anInt) {
        this.anInt = anInt;
    }

    public int getAnInt() {
        return anInt;
    }

    public void setAnInt(int anInt) {
        this.anInt = anInt;
    }
}
