package com.jingjiang.baidumusic.widget.single;

import android.content.Context;

import com.litesuits.orm.LiteOrm;

/**
 * Created by dllo on 16/7/9.
 */
public class SingleLiteOrm {
    private static SingleLiteOrm singleLiteOrm;
    private LiteOrm liteOrm;

    public LiteOrm getLiteOrm() {
        return liteOrm;
    }

    public static SingleLiteOrm getSingleLiteOrm(Context context) {
        if (singleLiteOrm == null) {
            synchronized (SingleLiteOrm.class) {
                if (singleLiteOrm == null) {
                    singleLiteOrm = new SingleLiteOrm();
                }
            }
        }
        return singleLiteOrm;
    }

}
