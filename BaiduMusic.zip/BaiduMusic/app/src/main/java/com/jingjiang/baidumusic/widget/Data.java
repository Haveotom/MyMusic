package com.jingjiang.baidumusic.widget;

/**
 * Created by dllo on 16/6/22.
 */
public class Data {
    /**
     * 个人中心
     * 精品应用 http://tingapi.ting.baidu.com/v1/restserver/ting?from=android&version=5.8.0.1&channel=xiaomi&operator=2&method=baidu.ting.plaza.recommend&qd=xiaomi
     * 活动专区
     * http://music.baidu.com/cms/nativeapp/activities/index.html?operator=2&musicch=xiaomi&fr=android&ver=5.8.0.1
     *更换背景
     * 1668 GET http://tingapi.ting.baidu.com/v1/restserver/ting?from=android&version=5.8.0.1&channel=xiaomi&operator=2&method=baidu.ting.skin.item&width=1080&height=1920 HTTP/1.1 	=> HTTP/1.1 200 OK	 [0.104 s]
     *
     *
     */


}
