package com.jingjiang.baidumusic.widget.myinterface;

/**
 * Created by dllo on 16/6/25.
 */
public interface OnDrawerListener {
    void closeDrawer();
    void openDrawer();
}
