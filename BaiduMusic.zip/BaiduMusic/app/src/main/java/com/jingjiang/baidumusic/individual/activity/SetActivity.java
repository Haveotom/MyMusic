package com.jingjiang.baidumusic.individual.activity;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseActivity;

/**
 * Created by dllo on 16/6/29.
 */
public class SetActivity extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_individual_set;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
