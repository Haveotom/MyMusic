package com.jingjiang.baidumusic.fragment;

import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseFragment;
import com.jingjiang.baidumusic.widget.myinterface.OnFragmentSkipListener;

/**
 * Created by dllo on 16/6/21.
 */
public class MyMusicFragment extends BaseFragment implements View.OnClickListener {
    private RelativeLayout locationRl, recentRl, downloadRl, iLikeRl, newSonglistRl;
    private int[] ids = {R.id.mymusic_bendi_rl, R.id.mymusic_recent_play_rl, R.id.mymusic_download_rl,
            R.id.mymusic_ilike_rl, R.id.mymusic_new_songlist_rl};
    private OnFragmentSkipListener skipListener;

    public void setSkipListener(OnFragmentSkipListener skipListener) {
        this.skipListener = skipListener;
    }

    @Override
    public void onAttach(Context context) {
        skipListener = (OnFragmentSkipListener) context;
        super.onAttach(context);
    }

    @Override
    protected int initLayout() {
        return R.layout.fragment_mymusic;

    }

    @Override
    protected void initView() {
        for (int i = 0; i < ids.length; i++) {
            bindView(ids[i]).setOnClickListener(this);
        }


    }

    @Override
    protected void initData() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mymusic_ilike_rl:
                if (skipListener != null) {
                    skipListener.toSkipFragment(7);
                }


                break;
            case R.id.mymusic_bendi_rl:
                break;
            case R.id.mymusic_recent_play_rl:
                break;
            case R.id.mymusic_download_rl:
                break;
            case R.id.mymusic_new_songlist_rl:
                break;
        }
    }
}
