package com.jingjiang.baidumusic.fragment;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseFragment;

/**
 * Created by dllo on 16/6/21.
 */
public class MyMusicFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.fragment_mymusic;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
