package com.jingjiang.baidumusic.activity;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseActivity;

/**
 * Created by dllo on 16/6/24.
 */
public class IndividualActivity extends BaseActivity implements View.OnClickListener {
    private LinearLayout returnLl;

    @Override
    protected int getLayout() {
        return R.layout.activity_individual;
    }

    @Override
    protected void initView() {
        returnLl = bindView(R.id.activity_individual_fanhui_ll);
        returnLl.setOnClickListener(this);

    }

    @Override
    protected void initData() {
        overridePendingTransition(R.anim.activity_in, R.anim.activity_out);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_individual_fanhui_ll:
                startActivity(new Intent(this, MainActivity.class));
                overridePendingTransition(R.anim.activity_out, R.anim.activity_close);
                break;
        }
    }
}
