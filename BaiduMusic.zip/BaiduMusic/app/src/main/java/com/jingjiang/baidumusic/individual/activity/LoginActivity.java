package com.jingjiang.baidumusic.individual.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseActivity;
import com.jingjiang.baidumusic.base.MyApplication;

//import cn.bmob.v3.Bmob;
//import cn.bmob.v3.BmobUser;
//import cn.bmob.v3.listener.SaveListener;

/**
 * Created by dllo on 16/6/29.
 */
public class LoginActivity extends BaseActivity implements View.OnClickListener {
    private ImageView returnIv, eyesIv;
    private TextView registerTv;
    private EditText phoneEt, passwordEt;
    private Button loginBtn;

    //在oncreate中初始化Bmob功能
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //有两种初始化的方法


    }

    @Override
    protected int getLayout() {
        return R.layout.activity_individual_login;
    }

    @Override
    protected void initView() {
        bindView(R.id.activity_login_return_iv).setOnClickListener(this);
        bindView(R.id.activity_login_password_eyes).setOnClickListener(this);
        bindView(R.id.activity_login_to_register_tv).setOnClickListener(this);
        phoneEt = bindView(R.id.activity_login_phone_et);
        passwordEt = bindView(R.id.activity_login_password_et);
        loginBtn = bindView(R.id.activity_login_login_btn);
        phoneEt.setOnClickListener(this);
        passwordEt.setOnClickListener(this);
        loginBtn.setOnClickListener(this);

    }

    @Override
    protected void initData() {
//        // 获得当前登录状态的user
//        BmobUser user1 = BmobUser.getCurrentUser(MyApplication.context);

    }

    private void login() {
//        BmobUser bmobUser = new BmobUser();
////        bmobUser.setUsername(user.getText().toString());
////        bmobUser.setPassword(loginPw.getText().toString());
//        bmobUser.login(MyApplication.context, new SaveListener() {
//            @Override
//            public void onSuccess() {
//                Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
//
//                // 获得当前登录状态的user
//                BmobUser user1 = BmobUser.getCurrentUser(MyApplication.context);
//                if (user1 != null) {
//
//                    finish();
//                }
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//                BmobUser user1 = BmobUser.getCurrentUser(MyApplication.context);
//                if (user1 == null) {
//                    Toast.makeText(LoginActivity.this, "登陆未成功", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//    private void register() {
//        BmobUser bmobUser = new BmobUser();
////        bmobUser.setUsername(user.getText().toString());
////        bmobUser.setPassword(registerPw.getText().toString());
//        bmobUser.signUp(MyApplication.context, new SaveListener() {
//            @Override
//            public void onSuccess() {
//                Toast.makeText(LoginActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//                Toast.makeText(LoginActivity.this, s, Toast.LENGTH_SHORT).show();
//            }
//        });
//
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_login_phone_et:
                break;
            case R.id.activity_login_password_et:
                break;
            case R.id.activity_login_password_eyes:
                break;
            case R.id.activity_login_login_btn:
                break;
            case R.id.activity_login_to_register_tv:
                break;
            case R.id.activity_login_return_iv:
                finish();
                break;

        }
    }
}
