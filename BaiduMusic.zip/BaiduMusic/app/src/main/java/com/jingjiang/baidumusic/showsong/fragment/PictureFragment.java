package com.jingjiang.baidumusic.showsong.fragment;

import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseFragment;
import com.jingjiang.baidumusic.inmymusic.SingleSongData;
import com.jingjiang.baidumusic.widget.eventbus.PlaySongEvent;
import com.jingjiang.baidumusic.widget.single.SingleLiteOrm;
import com.jingjiang.baidumusic.widget.single.SingleQueue;
import com.litesuits.orm.LiteOrm;
import com.litesuits.orm.db.assit.WhereBuilder;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Created by dllo on 16/7/2.
 */
public class PictureFragment extends BaseFragment implements View.OnClickListener {
    private ImageView pictureIv;
    private String picture;
    private ImageView noLikeIv, likeIv;
    private String title, name, songId;
    private static final String DB_SINGLE_SONG = "";
    private LiteOrm liteOrm;//数据库
    private SingleSongData singleSongData;

    @Override
    protected int initLayout() {
        return R.layout.showsong_f_picture;
    }

    public PictureFragment() {

        EventBus.getDefault().register(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void getImage(PlaySongEvent event) {
        picture = event.getData().getSonginfo().getPic_huge();

        title = event.getData().getSonginfo().getTitle();
        name = event.getData().getSonginfo().getAuthor();
        songId = event.getData().getSonginfo().getSong_id();
    }

    @Override
    protected void initView() {
        noLikeIv = bindView(R.id.showsong_f_picture_like_no_iv);
        likeIv = bindView(R.id.showsong_f_picture_like_yes_iv);
        pictureIv = bindView(R.id.showsong_f_picture_big_icon_iv);
        SingleQueue.getSingleQueue(getContext()).getImageLoader()
                .get(picture, ImageLoader.getImageListener(pictureIv, R.mipmap.default_album_playing, R.mipmap.default_album_playing));
        likeIv.setOnClickListener(this);
        noLikeIv.setOnClickListener(this);
        liteOrm = LiteOrm.newCascadeInstance(getContext(), DB_SINGLE_SONG);//创建数据库
        singleSongData = new SingleSongData();

    }


    @Override
    protected void initData() {

    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.showsong_f_picture_like_no_iv:
                addSingleSong();
                noLikeIv.setVisibility(View.GONE);
                likeIv.setVisibility(View.VISIBLE);
                Toast.makeText(getContext(), "已添加到我喜欢的单曲", Toast.LENGTH_SHORT).show();
                break;
            case R.id.showsong_f_picture_like_yes_iv:
                deleteSingleSong();
                likeIv.setVisibility(View.GONE);
                noLikeIv.setVisibility(View.VISIBLE);
                Toast.makeText(getContext(), "已取消喜欢", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void deleteSingleSong() {
//        liteOrm.delete(Integer.valueOf(songId));
    }

    private void addSingleSong() {
//        if (liteOrm.queryById(Integer.valueOf(songId), SingleSongData.class) == null) {
//            singleSongData.setSongId(songId);
//            singleSongData.setTitle(title);
//            singleSongData.setAuthor(name);
//            liteOrm.insert(singleSongData);//加入数据库
//        } else {
//            Toast.makeText(getContext(), "曾经就是我喜欢的单曲哦", Toast.LENGTH_SHORT).show();
//        }

    }

}
