package com.jingjiang.baidumusic.inksong;

import com.jingjiang.baidumusic.base.BaseFragment;

/**
 * Created by dllo on 16/6/28.
 */
public class ResumeDetailFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return 0;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
