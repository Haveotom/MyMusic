package com.jingjiang.baidumusic.inmymusic.fragment;

import android.content.Intent;
import android.view.View;
import android.widget.ListView;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseFragment;
import com.jingjiang.baidumusic.individual.activity.LoginActivity;
import com.litesuits.orm.LiteOrm;

/**
 * Created by dllo on 16/7/7.
 */
public class ILkeFragment extends BaseFragment implements View.OnClickListener {
    private ListView listView;
    private LiteOrm liteOrm;


    @Override
    protected int initLayout() {
        return R.layout.mymusic_f_ilike;
    }

    @Override
    protected void initView() {
        bindView(R.id.mymusic_f_like_return_ll).setOnClickListener(this);
        bindView(R.id.mymusic_f_like_login_tv).setOnClickListener(this);
        listView = bindView(R.id.mymusic_f_like_listview);

    }

    @Override
    protected void initData() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mymusic_f_like_return_ll:
                getFragmentManager().popBackStack();
                break;
            case R.id.mymusic_f_like_login_tv:
                startActivity(new Intent(getContext(), LoginActivity.class));
                break;
        }

    }
}
