package com.jingjiang.baidumusic.widget.eventbus;

/**
 * Created by dllo on 16/7/7.
 */
public class TypeEvent {
    private String type;

    public TypeEvent(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
