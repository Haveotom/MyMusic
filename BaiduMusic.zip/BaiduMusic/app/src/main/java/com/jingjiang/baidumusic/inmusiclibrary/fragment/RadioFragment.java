package com.jingjiang.baidumusic.inmusiclibrary.fragment;

import com.jingjiang.baidumusic.R;
import com.jingjiang.baidumusic.base.BaseFragment;

/**
 * Created by dllo on 16/6/21.
 */
public class RadioFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.music_f_radio;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
